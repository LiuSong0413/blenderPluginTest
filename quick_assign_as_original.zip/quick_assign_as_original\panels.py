# SPDX-License-Identifier: Apache-2.0
"""
panels.py
=========

UI 面板层 —— 在 3D 视图侧边栏（按 N 打开）注册一个 Tab。
不直接干活，只负责画按钮、调用 operators 中的算子。
"""

import bpy

from .operators import OBJECT_OT_gltf2_assign_as_original_selected


# ---------------------------------------------------------------------------
# 侧边栏面板
# ---------------------------------------------------------------------------
class VIEW3D_PT_quick_assign_as_original(bpy.types.Panel):
    """3D 视图 → N 侧边栏 → 「一键指定为原始」 Tab。"""

    bl_label = "一键指定为原始"          # 面板标题
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "一键指定为原始"        # 侧边栏 Tab 名称

    def draw(self, context):
        layout = self.layout

        # 1) 友好提示：未启用官方「材质变体」时给出明显警告，避免让用户疑惑
        if not hasattr(bpy.types.Mesh, "gltf2_variant_default_materials"):
            box = layout.box()
            box.label(text="请先启用「材质变体」", icon='ERROR')
            box.label(text="编辑 → 偏好设置 → 插件 →")
            box.label(text="glTF 2.0 → 勾选「材质变体」")
            return

        # 2) 显示当前选中的网格数量
        sel_meshes = [o for o in context.selected_objects if o.type == 'MESH']
        layout.label(text=f"当前选中网格：{len(sel_meshes)} 个")

        # 3) 主按钮（放大一点，醒目）
        col = layout.column(align=True)
        col.scale_y = 1.4
        col.operator(
            OBJECT_OT_gltf2_assign_as_original_selected.bl_idname,
            icon='CHECKMARK',
        )

        layout.separator()

        # 4) 操作说明
        box = layout.box()
        box.label(text="使用说明：", icon='INFO')
        col = box.column(align=True)
        col.label(text="1. 把每个模型切到想导出的变体")
        col.label(text="2. 全选这些模型（A 键）")
        col.label(text="3. 点上方按钮")
        col.label(text="4. 正常导出 glTF 即可")


# ---------------------------------------------------------------------------
# Register
# ---------------------------------------------------------------------------
classes = (
    VIEW3D_PT_quick_assign_as_original,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
