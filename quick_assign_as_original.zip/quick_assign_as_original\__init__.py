# SPDX-License-Identifier: Apache-2.0
"""
一键指定为原始 (Quick Assign as Original)

为 Blender 内置 glTF 2.0 插件的「材质变体（Material Variants）」功能
补充批量操作能力：一键将所有选中网格当前显示的材质指定为它们各自的「原始」。

依赖：必须先在 Blender 内置 glTF 2.0 插件偏好设置中勾选「材质变体」。

模块拆分：
    __init__.py  ── 插件元信息 / 注册入口
    operators.py ── 算子（实际执行逻辑）
    panels.py    ── 侧边栏 UI 面板
"""

bl_info = {
    "name": "一键指定为原始",
    "author": "Custom",
    "version": (1, 0, 0),
    "blender": (4, 0, 0),
    "location": "3D 视图 > 侧边栏(N) > 一键指定为原始",
    "description": "批量将所有选中网格当前显示的材质指定为各自的「原始」（用于 glTF 材质变体导出）",
    "category": "Import-Export",
    "support": "COMMUNITY",
}

# 在多文件插件中，模块需要在 register() 期间从包内导入。
# 使用相对导入并配合 importlib.reload，便于开发时反复重载。
import importlib

from . import operators
from . import panels

# 开发时支持「重载脚本」：重新加载子模块，避免残留旧类
if "_loaded" in locals():
    importlib.reload(operators)
    importlib.reload(panels)
_loaded = True


def register():
    """Blender 启用插件时调用：注册算子 → 注册面板。"""
    operators.register()
    panels.register()


def unregister():
    """Blender 停用/卸载插件时调用：按相反顺序注销。"""
    panels.unregister()
    operators.unregister()


if __name__ == "__main__":
    register()
