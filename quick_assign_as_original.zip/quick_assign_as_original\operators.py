# SPDX-License-Identifier: Apache-2.0
"""
operators.py
============

算子（Operator）层 —— 真正干活的代码都在这里。
本插件目前只提供一个算子：把所有选中 MESH 当前的材质，指定为各自的「原始」。
"""

import bpy


# ---------------------------------------------------------------------------
# 批量「指定为原始」算子
# ---------------------------------------------------------------------------
class OBJECT_OT_gltf2_assign_as_original_selected(bpy.types.Operator):
    """对所有选中的网格物体，把它们当前显示的每个材质，
    分别记录为该物体在 glTF 材质变体中的「原始（Original）」材质。"""

    bl_idname = "object.gltf2_assign_as_original_selected"
    bl_label = "将选中物体指定为原始"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        # 至少要有一个选中的网格物体，否则按钮置灰
        return any(o.type == 'MESH' for o in context.selected_objects)

    def execute(self, context):
        # 1) 检查官方 glTF 插件的「材质变体」属性是否已注册
        #    它只有在 Blender 偏好里勾选「材质变体」后才会出现
        if not hasattr(bpy.types.Mesh, "gltf2_variant_default_materials"):
            self.report(
                {'ERROR'},
                "请先在 glTF 2.0 插件偏好设置中勾选「材质变体」。"
            )
            return {'CANCELLED'}

        # 2) 过滤出选中的 MESH（灯光/相机/空物体等直接跳过）
        mesh_objects = [o for o in context.selected_objects if o.type == 'MESH']
        if not mesh_objects:
            self.report({'WARNING'}, "没有选中任何网格物体。")
            return {'CANCELLED'}

        processed_obj_count = 0
        processed_slot_count = 0

        # 3) 复刻官方 SCENE_OT_gltf2_assign_as_original 的写入逻辑，
        #    只是把作用对象从「活动物体」换成「每个选中的 MESH」。
        #    多个物体可能共享同一份网格数据（linked data），用集合去重避免重复写入。
        seen_meshes = set()

        for obj in mesh_objects:
            mesh = obj.data
            if mesh is None or mesh.name in seen_meshes:
                continue
            seen_meshes.add(mesh.name)

            for mat_slot_idx, slot in enumerate(obj.material_slots):
                # 在已有 default_materials 中查找当前 slot 是否已有记录
                found = False
                for entry in mesh.gltf2_variant_default_materials:
                    if entry.material_slot_index == mat_slot_idx:
                        # 已存在 → 更新为当前显示的材质
                        entry.default_material = slot.material
                        found = True
                        break

                if not found:
                    # 不存在 → 新建一条记录
                    new_entry = mesh.gltf2_variant_default_materials.add()
                    new_entry.material_slot_index = mat_slot_idx
                    new_entry.default_material = slot.material

                processed_slot_count += 1

            processed_obj_count += 1

        # 4) 操作完成后给个提示，方便确认到底处理了几个
        self.report(
            {'INFO'},
            f"已为 {processed_obj_count} 个网格、共 {processed_slot_count} 个材质槽指定原始。"
        )
        return {'FINISHED'}


# ---------------------------------------------------------------------------
# Register
# ---------------------------------------------------------------------------
classes = (
    OBJECT_OT_gltf2_assign_as_original_selected,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
